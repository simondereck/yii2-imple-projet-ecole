<?php
/**
 * Created by PhpStorm.
 * User: 37vip
 * Date: 25/11/2019
 * Time: 14:35
 */
?>

<div class="actualites">
    <div class="top-bar-img">
        <img src="../../images/iplme/actualites.jpg"/>
        <div>Actualités</div>
    </div>
    <div class="actualites-info">
        <section class="grid-x color-primary">
            <div class="cell" style="">
                <p>À partir de maintenant, vous pouvez vérifier les résultats de l'examen final. Les relevés de notes officiels seront émis à la fin de juillet.<br><br>Pour les résultats d'examen final, s'il vous plaît envoyer votre nom, à l'adresse e-mail: iplmeparis@gmail.com.<br><br>
                    Veuillez également prêter attention à l'email et le numéro public officiel IPLME: iplme0145300229.<br><br> Si vous avez d'autres questions, n'hésitez pas à nous contactez directement par e-mail ou via le service client de WeChat: iplme_paris ou par téléphone: 01 45 30 02 29.
                </p>
            </div>
        </section>
    </div>
    <div class="actualites-list">
        <div class="actualites-list-info">
            <h4>Vacances d'été 2018 </h4>
            <p>
                Les vacances commencent le samedi 30 juillet 2018 et prennent fin le mercredi 15 août 2018.
            </p>
        </div>
        <div><img src="../../images/iplme/actualites_1.jpg"></div>
    </div>
</div>

<style>
    body{
        background: whitesmoke;
    }

    .actualites{
        width: 60vw;
        margin: 20px auto 20px;
        background-color: white;
        font-size: 1vw;
    }
    .top-bar-img,.top-bar-img img{
        width: 60vw;
        height: 20vw;
        position: relative;
    }

    .top-bar-img div{
        font-size: 2vw;
        color: white;
        padding: 2vw;
        position: absolute;
        top: 0;
        z-index: 200;
    }

    img{
        object-fit: cover;
    }

    .actualites-info{
        background-color: #1b6d85;
        color: white;
        padding: 2vw;
    }
    .actualites-list{
        display: flex;
    }
    .actualites-list img,.actualites-list-info{
        width: 30vw;
        height: 20vw;
    }

    .actualites-list-info{
        padding: 2vw;
    }

    h4{
        font-size: 1.5vw;
        font-weight: bold;
    }

</style>
