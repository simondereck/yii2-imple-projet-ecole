<?php
/**
 * Created by PhpStorm.
 * User: 37vip
 * Date: 25/11/2019
 * Time: 15:25
 */

?>

<div class="association">
    <div class="top-bar-img">
        <img src="../../images/iplme/association.jpg" />
        <div>Association des anciens</div>
    </div>
    <div class="association-items">
        <div class="association-item">
            <div class="association-item-description">
                <h4>Réseaux d’anciens</h4>
                <p>
                    Le réseau couvre plus de 200 membres de la communauté et
                    comprend 23 000 anciens étudiants et 4 700 étudiants de différents projets IPLME.
                </p>
                <p>
                    Plus de 250 ambassadeurs des anciens se sont engagés à soutenir le réseau:
                </p>
                <ul>
                    <li>
                        Pour chaque projet .Les ambassadeurs étudiants sont responsables de
                        communiquer avec les étudiants et les anciens ;
                    </li>
                    <li>
                        Les ambassadeurs de classe assureront le contact entre leurs camarades
                        de classe, l'école et le réseau des anciens ;
                    </li>
                    <li>
                        Les ambassadeurs de la communauté internationale organiseront des
                        rencontres informelles avec des diplômés étrangers et accueilleront
                        des étudiants pour des stages internationaux ou des échanges académiques ;
                    </li>
                    <li>
                        Les ambassadeurs de la communauté française resteront en contact avec
                        les diplômés des grandes villes françaises ;
                    </li>
                    <li>
                        L'ambassadeur du club organisera des conférences et des réunions spéciales
                        sur certains sujets d'actualité à Paris ;
                    </li>
                </ul>

            </div>
            <div class="association-item-img">
                <img src="../../images/iplme/association_1.jpg"/>
            </div>
        </div>
        <div class="association-item">
            <div class="association-item-img">
                <img src="../../images/iplme/association_2.jpg"/>
            </div>
            <div class="association-item-description">
                <h4>Équipe des anciens</h4>
                <p>
                    L'équipe des anciens fait le lien entre les anciens diplômés, les associations, les entreprises, les recruteurs et les partenaires de l'école.
                </p>
                <p>
                    Notre rôle：
                </p>
                <ul>
                    <li><h4>Se connecter：</h4>Créer, renforcer et maintenir des liens entre les étudiants, les anciens et les écoles pour assurer l'unité au sein du réseau des anciens.</li>
                    <li><h4>Améliorer：</h4>Permettre aux étudiants et aux diplômés de se dévoiler pleinement en démontrant leur développement professionnel, leurs qualifications académiques et leur école.</li>
                    <li><h4>développer：</h4>Permet aux étudiants et aux diplômés de contribuer au développement et à l'expansion de leurs réseaux et écoles.</li>
                </ul>
                <br>
                <p>
                    Contactez-nous:
                </p>
                <p>
                    Email: info@iplme.org
                </p>
                <p>
                    Téléphone: +33 (0)1 45 30 02 29
                </p>

            </div>
        </div>
    </div>
</div>

<style>
    body{
        background-color: whitesmoke;

    }

    .association{
        margin: 20px auto 20px;
        background-color: white;
        width: 60vw;
    }

    .top-bar-img,.top-bar-img img{
        width: 60vw;
        height: 20vw;
        position: relative;
    }

    .top-bar-img div{
        font-size: 2vw;
        color: white;
        padding: 2vw;
        position: absolute;
        top: 0;
        z-index: 200;
    }

    img {
        object-fit: cover;
    }


    .association-item{
        display: flex;
    }

    .association-item-img,
    .association-item-img img,
    .association-item-description{
        width: 30vw;
    }

    .association-item-img img{
        height: 100%;
    }

    .association-item-description{
        font-size: 1vw;
        padding: 2vw;
    }

    h4{
        font-weight: bold;
        font-size: 1.5vw;
    }
</style>
