<?php
/**
 * Created by PhpStorm.
 * User: 37vip
 * Date: 25/11/2019
 * Time: 15:25
 */

?>

<div class="vie">
    <div class="top-bar-img">
        <img src="../../images/iplme/vie.jpg" />
        <div>La vie étudiante</div>
    </div>
    <div class="vie-info">
        <h4>Bienvenue à l'IPLME</h4>
        <p>Les étudiants de l’IPLME viennent du monde entier (plus de 30 pays)!
            L’équipe de travail est composés d’individus de culture nationale différente,
            mais qui ont tous deux choses en commun: optimisme et créativité!</p>
    </div>
    <div class="vie-item">
        <div class="vie-item-img"><img src="../../images/iplme/vie_1.jpg" /></div>
        <div class="vie-item-detail">
            <div class="vie-item-description">
                <h4>IPLME</h4>
                <p>L’IPLME a son propre cercle social, avec environ 30 clubs d'étudiants,
                    et organise souvent une variété d'événements sportifs et culturels.
                    Voici quelques façons de vous aider à vous faire de nouveaux amis:</p>
            </div>
            <div class="vie-item-subview">
                <ul class="vie-item-subview-title">
                    <li class="active" data-val="0">Clubs d'étudiants</li>
                    <li data-val="1">Campus</li>
                    <li data-val="2">Service étudiante</li>
                </ul>
                <div class="vie-item-subview-items">
                    <div class="vie-item-subview-item" data-val="0">
                        <p>Participer à son activité préférée et faire des différents
                        projets avec étudiants de différents horizons et différents pays.
                        Rejoindre différents clubs de campus vous fera certainement trouver
                            un groupe d'amis partageant les mêmes idées.</p>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Forest Hill Aquaboulevard</a>
                            <div class="accordion-info hidden">
                                Ce club de fitness propose une variété de cours,
                                y compris des cours de danse, d'étirement,
                                Sports de combat, natations, etc.
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Atelier Vin</a>
                            <div class="accordion-info hidden">
                                Organisez des dégustations de vins,
                                des cours de vinification, des visites de
                                vignobles et l'exploration de la cuisine
                                régionale française.
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Mode et Gastronomie</a>
                            <div class="accordion-info hidden">
                                Participer à une variété d'activités de l'industrie du luxe
                                et des pratiques d'entreprise, organiser un certain nombre de
                                " voyage de luxe."
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Activité et Événements</a>
                            <div class="accordion-info hidden">
                                En organisant de grandes ou de petites soirées,
                                les étudiants s'intéresseront plus aux disciplines
                                culturelles et artistiques, y compris la danse,
                                la musique et les arts visuels.
                            </div>
                        </div>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="1">
                        <h4>美丽校园 & 方便设施</h4>
                        <p>
                            IPLME位于法国巴黎市市中心，学习环境优美。紧邻于塞纳河畔，是巴黎市最古老的区域之一，
                            周边众多繁类的历史建筑及其人文景观营造出了良好的学习氛围，同时在学校周边有诸多国家图书馆和历史博物馆，
                            学生在学习之余可以尽情的游览和感受厚重的法国历史和法国文化.
                        </p>
                        <h4>设施</h4>
                        <p>我们的设施既现代又舒适，为学生的学习及生活提供便利。</p>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">图书馆</a>
                            <div class="accordion-info hidden">
                                这里有各类图书教材、有经验丰富的老师、有便捷的计算机网络、有温馨舒适的学习环境。
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">金融交易室</a>
                            <div class="accordion-info hidden">
                                最先进的金融交易室提供通常只为财务专业人士预留的一系列服务。
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">餐厅</a>
                            <div class="accordion-info hidden">
                                自助餐厅位于一楼，供应热饮，苏打水，羊角面包和其他小吃。
                                午餐时间，提供三明治和餐点，也可以从家里自带食物。
                                五分钟步行路程内，还有许多实惠且美味的选择。。
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">活动场所</a>
                            <div class="accordion-info hidden">
                                IPLME已与健身房 Forest Hill 和欧洲最大的水上乐园 Aquaboulevard 建立合作关系，
                                学生可以进行羽毛球、网球等团队运动，还有设备齐全的健身中心，进行舞蹈，瑜伽等活动。
                            </div>
                        </div>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="2">
                        <h4>国际关系办公室</h4>
                        <p>我们有一个专门的学生服务团队，为学生提供指导和建议：</p>
                        <ul>
                            <li>学生签证</li>
                            <li>住房合同</li>
                            <li>开立银行账户</li>
                            <li>课程信息和成绩单</li>
                            <li>法国社会保险</li>
                            <li>校园信息</li>
                            <li>CAF住房津贴</li>
                            <li>学生会</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="vie-item">
        <div class="vie-item-detail">
            <div class="vie-item-description">
                <h4>Paris</h4>
                <p>Paris possède une histoire de plus de 1400 ans,
                    il est, non seulement pour la France,
                    mais aussi pour l’Europe occidental,
                    le centre politique, économique et culturel.
                </p>
                <ul>
                    <li>
                        À paris, vous pouvez découvrir les meilleures œuvres dans
                        les domaines de l’art, de la culture et du patrimoine.
                        Outre les monuments historiques et les nombreux châteaux
                        que les gens peuvent visiter en plein air, ils constituent
                        également la capitale de nombreuses cultures et arts.
                    </li>
                    <li>
                        Sur les Champs-Élysées, en plus de faire du shopping,
                        vous pouvez profiter des plus beaux paysages ainsi
                        que des attractions touristiques connues.
                    </li>
                    <li>
                        Si vous visitez l’avenue Montaigne, où vous pourrez
                        non seulement admirer les boutiques de plus grands
                        produits de luxe du monde, mais aussi profiter des
                        plats alléchants dans les restaurants raffinés le long de la rue.
                    </li>
                    <li>
                        Vous trouverez partout des lieux historiques très bien protégés,
                        des œuvres d’art et des architectures exquises et délicates.
                        Les efforts exigés par la fabrication de ces
                        travaux d’artisanat sont surprenants.
                    </li>
                    <li>
                        La poursuite du style et de la beauté des Parisiens se traduit par
                        leur façon de s’habiller, leurs desserts, chaque détaille compte dans
                        cette poursuite.
                    </li>
                </ul>
            </div>
            <div class="vie-item-subview">
                <ul class="vie-item-subview-title">
                    <li class="active" data-val="0">La ville de Paris</li>
                    <li data-val="1">Vie quotidienne et amusement</li>
                </ul>
                <div class="vie-item-subview-items">
                    <div class="vie-item-subview-item" data-val="0">
                        <p>
                            Chaque rue de Paris a sa propre histoire, ce sont les écrivains,
                            les grandes scientifiques, les martyrs, les artistes, l’amour et la
                            liberté qui rend cette ville romantique. Il existe de nombreuses possibilités
                            et imaginations pour la vie.
                        </p>
                        <p>
                            Étant étroitement liée à la mode, Paris est également une ville masculine.
                            Les bâtiments se caractérisent par une grande échelle et une décoration magnifique.
                            C'est ce genre de style royal qui est devenu une source créative pour le commerce à
                            l'avenir.
                        </p>
                        <p>
                            Les bâtiments des deux côtés de la Seine sont les insignes et les armes de la ville,
                            en défendant Paris, ils brillent dans la lumière dorée du soleil.
                        </p>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="1">
                        <p>
                            Plein de choses à découvrir à Paris. Visitez le site officiel du tourisme Paris pour
                            plus d'informations.Visitez le site officiel du tourisme Paris pour plus d'informations.
                        </p>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Trafic</a>
                            <div class="accordion-info hidden">
                                <p>
                                    Les étudiants peuvent choisir de marcher, faire du vélo, du tram, du bus, du taxi,
                                    louer une voiture ou même faire un tour en bateau à Nantes. Nantes est bien desservie
                                    par les transports en commun, c’est une ville très adaptée pour marche à pied.
                                </p>
                                <p>
                                    Possédant l’Aéroports Paris-Charles-de-Gaulle et l’Aéroport de Paris - Orly,
                                    Paris est une ville qui vous permet de rejoindre facilement des destinations
                                    internationales.
                                </p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Nourriture et nécessités quotidiennes</a>
                            <div class="accordion-info hidden">
                                <p>
                                    La nourriture fait partie primordiale de la vie en France.
                                    Il existe de nombreux supermarchés, centres commerciaux et marchés
                                    en plein air à Paris. Il est plus rentable d'acheter des produits
                                    agricoles de haute qualité sur le marché des agriculteurs de plein
                                    air et d'acheter des articles ménagers tels que des couvertures et
                                    des produits de nettoyage dans les grands supermarchés.
                                </p>
                                <p>
                                    La nourriture parisienne a un bon rapport qualité-prix, les étudiants peuvent
                                    déguster de délicieux fruits, légumes, fromages français, etc. à des prix avantageux.
                                    Des cartes de membre du magasin permettent plus d'avantages lors de l’achat.
                                </p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Restauration et divertissements</a>
                            <div class="accordion-info hidden">
                                <p>
                                    En tant que capitale de la gastronomie, vous pouvez trouver tout
                                    ce qu’il vous plaît dans le domaine de restauration : soit des
                                    nourritures européennes comme la cuisine française, italienne,
                                    soit des nourritures asiatiques, comme la cuisine chinoise et
                                    japonaise, voire des plats d’Amérique comme les cuisines argentines,
                                    cubaines, mexicaines, etc. Vous pourrez également y déguster des plats
                                    africains et arabes. Les boissons telles que le thé, le café ainsi que les
                                    desserts sont également à votre choix.
                                </p>
                                <p>
                                    Les sorties du soir à Paris sont également très diversifiées :
                                    les trois spectacles les plus célèbres à Paris : "Crazy Horse Show",
                                    le "Lido" et le "Moulin Rouge".
                                </p>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a class="accordion-title before-active">Sports</a>
                            <div class="accordion-info hidden">
                                <p>
                                    IPLME propose des clubs de fitness pour des étudiants, parce exemple,
                                    Forest Hill et Aquaboulevard. Ces clubs proposent de nombreux cours,
                                    ainsi que les diverses installations pour la natation, le tennis,
                                    le yoga, le sauna, le cyclisme et les sources thermales.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="vie-item-img"><img src="../../images/iplme/vie_2.jpg" /></div>
    </div>
    <div class="vie-item">
        <div class="vie-item-img"><img src="../../images/iplme/vie_3.jpg" /></div>
        <div class="vie-item-detail">
            <div class="vie-item-description">
                <h4>France</h4>
                <p>La France est l'une des destinations touristiques les plus populaires au monde.
                    En tant qu’étudiant, vous pouvez profiter au maximum de la beauté de France.
                </p>
            </div>
            <div class="vie-item-subview">
                <ul class="vie-item-subview-title">
                    <li class="active" data-val="0">la position géographique</li>
                    <li data-val="1">gastronomique</li>
                    <li data-val="2">art</li>
                    <li data-val="3">pays</li>

                </ul>
                <div class="vie-item-subview-items">
                    <div class="vie-item-subview-item" data-val="0">
                        <p>
                            Située au cœur de l’Europe occidentale, la France est amicale avec ses
                            voisins et offre un accès facile à de nombreux pays voisins tels que l’Italie,
                            la Suisse, l’Espagne et l’Allemagne.
                        </p>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="1">
                        <p>
                            Si la nourriture est importante pour vous, alors la France est votre meilleur choix !
                            Les sauces, fromages, pains, vins et desserts sont mondialement connus.
                            La culture culinaire française est constituée par une cuisine superbe,
                            une longue histoire et beaucoup de plaisirs.
                        </p>
                        <p>
                            En France, vous pouvez prendre votre temps et déguster des plats gastronomiques.
                            Des promenades dehors quand il fait beau, des petits repos dans un café,
                            des repas dans des restaurants ou sur des marchés, ou des pique-niques dans un parc,
                            tout cela rendra votre journée plus intéressante.
                        </p>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="2">
                        <p>
                            La France est depuis longtemps l’un des centres d'art internationaux,
                            y compris le plus connu, <a href="https://www.louvre.fr/en">le musée du Louvre.</a>
                        </p>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="3">
                        <p>
                            La campagne française est connue pour ses paysages magnifiques,
                            ses vignobles et ses villages historiques. Ayant de longues histoires,
                            ces villages sont très animés jusqu’à nos jours,
                            allant des villes balnéaires aux villages pittoresques du canal,
                            en passant par de jolies communautés à flanc de colline ou des villages perchés
                            au bord d’une falaise.
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="vie-item">
        <div class="vie-item-detail">
            <div class="vie-item-description">
                <h4>Logement</h4>
                <p>
                    Les étudiants ont de nombreuses options d'hébergement,
                    y compris des résidences d'étudiants, des familles d'accueil et des appartements.
                    L'école fournit de temps en temps des informations concernant au logement.
                </p>
                <p>
                    Site Web Intermédiaire
                    Site professionnel http://www.seloger.com
                    https://www.crous-paris.fr/
                    Appartement étudiant http://www.seloger.com
                    Appartement familial https://www.location-etudiant.fr/
                    http://www.logement-etudiant.com/
                </p>
                <p>
                    En France, si vous louez une maison ou un appartement privé,
                    vous pouvez obtenir une prestation financière.
                    Visitez la Caisse d’allocations familiales (CAF) pour savoir si vous avez le droit légitime,
                    d’après le système national d'allocation de logement.
                    Pour plus d'informations sur l’aide au logement, veuillez visiter le site web de CampusFrance.
                </p>
                <p>
                    Attention : pour obtenir l’aide au logement, lors de votre arrivée en France,
                    vous devez fournir les informations suivantes à votre CAF:
                </p>
                <ul>
                    <li>
                        passeport
                    </li>
                    <li>
                        contrat de logement
                    </li>
                    <li>
                        carte d'étudiant française
                    </li>
                    <li>
                        Acte de naissance (avec la traduction en français)
                    </li>
                    <li>
                        numéro ou carte de la sécurité sociale
                    </li>
                    <li>
                        Trois photos de passeport
                    </li>
                    <li>
                        Un visa d’étudiant valable et un formulaire de demande d’attestation de visa de long séjour tamponné (OFII)
                    </li>
                </ul>
            </div>
        </div>
        <div class="vie-item-img"><img src="../../images/iplme/vie_4.jpg" /></div>
    </div>
    <div class="vie-item">
        <div class="vie-item-img"><img src="../../images/iplme/vie_5.jpg" /></div>
        <div class="vie-item-detail">
            <div class="vie-item-description">
                <h4>Coût de la vie</h4>
                <p>
                    Vous trouverez ci-dessous le budget de vos dépenses pendant votre séjour à Paris.
                    Bien entendu, la situation de chaque élève est différente et vos habitudes de
                    consommation détermineront si vous êtes au-dessus ou au-dessous de la moyenne budgétaire.
                </p>
            </div>
            <div class="vie-item-subview">
                <ul class="vie-item-subview-title">
                    <li class="active" data-val="0">divertissement</li>
                    <li data-val="1">frais de subsistance</li>
                </ul>
                <div class="vie-item-subview-items">
                    <div class="vie-item-subview-item" data-val="0">
                        <p>
                            Les coûts suivants sont à titre indicatif uniquement :
                        </p>
                        <table class="table">
                            <tbody>
                            <tr>
                                <th scope="row">Cinéma </th>
                                <td>Tarif étudiant:</td>
                                <td>€7.00</td>
                            </tr>
                            <tr>
                                <th scope="row">Musée </th>
                                <td>Tarif étudiant:</td>
                                <td>€5-10</td>
                            </tr>
                            <tr>
                                <th scope="row">Opéra</th>
                                <td>Tarif étudiant:</td>
                                <td>€10-30 (variable selon les places)</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="vie-item-subview-item hidden" data-val="1">
                        <table class="table">
                            <tbody>
                            <tr>
                                <th scope="row">Loyer/mois</th>
                                <td>Famille d’accueil：<br>
                                    Appartement privé：<br>
                                    Hôtel：</td>
                                <td>€350<br>
                                    €450-600<br>
                                    €450-700</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">L’électricité/gaz/boxe </th>
                                <td rowspan="1">Electricité：<br>
                                    Gaz：<br>
                                    Boxe：</td>
                                <td rowspan="1">€15-30<br>
                                    €15-30<br>
                                    €15-30</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Sécurité sociale (assurance)</th>
                                <td rowspan="1"></td>
                                <td rowspan="1">€215/an</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Consultation </th>
                                <td rowspan="1"></td>
                                <td rowspan="1">€20-40/fois</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Transport </th>
                                <td rowspan="1">Vélo<br>
                                    Bus<br>
                                    Tramway：<br>
                                    Carte mensuelle：<br>
                                    Carte annuelle：<br>
                                    la prise en charge du taxi：</td>
                                <td rowspan="1">€10/jour, €20/semaine, €30/mois<br>
                                    €1.50<br>
                                    €1.50<br>
                                    €34<br>
                                    €250<br>
                                    €2+tarif de kilomètre</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Téléphone fix</th>
                                <td rowspan="1">Forfait mensuel (sans frais d’installation)：</td>
                                <td rowspan="1">€20-40</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Portable </th>
                                <td rowspan="1">Carte SIM：<br>
                                    Sans contrat (prépayé)：<br>
                                    Avec contrat(1-2ans)：</td>
                                <td rowspan="1">€20<br>
                                    €5-30<br>
                                    €30-50/mois</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Nourriture </th>
                                <td rowspan="1">
                                    Epicerie：<br>
                                    Baguette：<br>
                                    1kg du spaghetti：<br>
                                    1kg du riz：<br>
                                    Fast food：<br>
                                    6 œufs：<br>
                                    Sandwich：<br>
                                    Restaurant：<br>
                                </td>
                                <td rowspan="1">€120/mois<br>
                                    €0.80<br>
                                    €1.20<br>
                                    €1.90<br>
                                    €7.00<br>
                                    €1.50<br>
                                    €3-5<br>
                                    €15-20/per</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Lavage</th>
                                <td rowspan="1">Lessive：<br>
                                    Séchage：</td>
                                <td rowspan="1">€3/fois<br>
                                    €1/fois</td>
                            </tr>
                            <tr>
                                <th rowspan="1" scope="row">Coupe de chevaux </th>
                                <td rowspan="1">Homme：<br>
                                    Femme：</td>
                                <td rowspan="1">€15-25<br>
                                    €20-60</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('.vie-item-subview-title').on('click','li',function () {
        $(this).parent('ul').children('li').each(function ($key,$item) {
            $($item).removeClass('active');
        });
        $(this).addClass('active');
        let val = $(this).attr('data-val');
        $(this).closest('.vie-item-subview').find('.vie-item-subview-item').each(function (key,item) {
            if ($(item).attr('data-val')===val){
                // $(item).show();
                $(item).removeClass('hidden');
            } else{
                $(item).addClass('hidden');
            }
        });
    });

    $('.accordion-item').on('click','a',function () {
        let select = $(this).parent().children('.accordion-info');
        if (select.hasClass('show')){
            select.removeClass('show');
            select.addClass('hidden');
            $(this).removeClass('after-active');
            $(this).addClass('before-active');
        } else{
            $(this).closest('.vie-item-subview-item').find('.show').each(function ($key,$item) {
                $($item).removeClass('show');
                $($item).addClass('hidden');
            });
            $(this).parent().children('.accordion-info').removeClass('hidden');
            $(this).parent().children('.accordion-info').addClass('show');
            $(this).closest('.vie-item-subview-item').find('a').each(function ($key,$item) {
                console.log($key,$item);
                if ($($item).hasClass('after-active')){
                    $($item).removeClass('after-active');
                    $($item).addClass('before-active');
                }
            });
            $(this).removeClass('before-active');
            $(this).addClass('after-active');
        }

    });

</script>

<style>
    body{
        background-color: whitesmoke;
    }

    .vie{
        width: 60vw;
        margin: 20px auto 20px;
        background-color: white;
        font-size: 1vw;
    }

    .top-bar-img,.top-bar-img img{
        width: 60vw;
        height: 20vw;
        position: relative;
    }

    .top-bar-img div{
        font-size: 2vw;
        color: white;
        padding: 2vw;
        position: absolute;
        top: 0;
        z-index: 200;
    }
    img{
        object-fit: cover;
    }

    h4{
        font-size: 1.5vw;
        font-weight: bold;
    }

    .vie-info{
        padding: 2vw;
        background-color: #1b6d85;
        color: white;
    }

    .vie-item{
        display: flex;
    }

    .vie-item-detail,.vie-item-img,.vie-item-img img{
        width: 30vw;
    }

    .vie-item-img img{
        height:100%;
    }

    .vie-item-description{
        padding: 2vw;
    }

    .vie-item-subview-title{
        padding: 6px;
        border-bottom: 1px grey solid;
    }
    .vie-item-subview-title li{
        display: inline;
        padding: 6px;
        font-size: 1vw;
        list-style: none;
    }

    .vie-item-subview-title li:hover{
        cursor: pointer;
    }
    .active{
        background-color: rgba(0,0,0,0.2);
        font-weight: bold;
    }

    .vie-item-subview-items{
        padding: 2vw;
    }

    .hidden{
        display: none;
    }

    .show{
        display: block;
    }
    .accordion-item{
        background-color: whitesmoke;
        margin-bottom: 5px;

    }
    .accordion-title{
        padding: 5px;
        background-color: #122b40;
        color: white;
        display: inline-block;
        width: 100%;
    }

    .accordion-title:hover{
        color: white;
        text-decoration: none;
        background-color: #1b6d85;
        cursor: pointer;
    }

    .before-active::after{
        content: "+";
        float: right;
    }
    .after-active::after{
        content: "-";
        float: right;
    }

    .accordion-info{
        padding: 10px;
    }

</style>
