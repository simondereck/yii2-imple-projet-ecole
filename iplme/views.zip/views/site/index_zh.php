<?php

/* @var $this yii\web\View */
$this->title = 'IPLME';
?>
<div class="top-bar-img">
    <img src="../../images/iplme/paris.jpg"/>
</div>
<div class="site-index">

    <div class="programmes">
        <h2>专业课程</h2>
        <div class="programes-sets">
            <div class="programme-item" data-val="bba">
                <img src="../../images/programe/bba.jpg"/>
                <div class="programme-item-name">BBA</div>
            </div>
            <div class="programme-item" data-val="mba">
                <img src="../../images/programe/mba.jpg"/>
                <div class="programme-item-name">MBA</div>
            </div>
            <div class="programme-item" data-val="dba">
                <img src="../../images/programe/dba.jpg"/>
                <div class="programme-item-name">DBA</div>
            </div>
            <div class="programme-item" data-val="stage">
                <img src="../../images/programe/stage.jpg"/>
                <div class="programme-item-name">实习</div>
            </div>
            <div class="programme-item" data-val="fle">
                <img src="../../images/programe/fle.jpg"/>
                <div class="programme-item-name">语言班</div>
            </div>
            <div class="programme-item" data-val="prepa">
                <img src="../../images/programe/prepa.jpg"/>
                <div class="programme-item-name">预科班</div>
            </div>
            <div class="programme-item" data-val="ete">
                <img src="../../images/programe/cours_ete.jpg"/>
                <div class="programme-item-name">短期项目</div>
            </div>
            <div class="programme-item" data-val="gymnase">
                <img src="../../images/programe/gymnase.jpg"/>
                <div class="programme-item-name">健身项目</div>
            </div>
            <div class="programme-item" data-val="cvec">
                <img src="../../images/programe/cvec.jpg"/>
                <div class="programme-item-name">学生保险</div>
            </div>
        </div>
    </div>
</div>
<script>
    $('.programmes').on('click','.programme-item',function () {
       let val = $(this).attr('data-val');
       if(val==="cvec"){
           window.location = "https://www.messervices.etudiant.gouv.fr/envole/";
       }else{
           window.location = 'index.php?r=programe/'+val;
       }
    });

</script>
<style>
    body {
        background: whitesmoke;
    }

    .programmes{
        background: white;
        margin: 20px auto 20px;
        width: 81vw;
    }

    .programmes h2{
        width: fit-content;
        margin: 2vw auto 2vw;
        color: #1b6d85;
        padding: 10px;
        border-bottom: 3px solid black ;
    }


    .col-lg-4 p{
        width: 200px;
        margin: auto;
        margin-bottom: 10px;
    }

    .col-lg-4 img{
        width: 80px;
        height: 80px;
    }


    .wrap > .container {
        padding: 50px 0px 0px;
    }


    .programme-item{
        width: 24vw;
        height: 16vw;
        display: inline-block;
        text-align: center;
        margin: 1vw 1.3vw 1vw;
        background-color: cadetblue;
        position: relative;
        box-shadow: 0px 0px 2px 1px rgba(0, 0, 0, .2);
        overflow: hidden;
    }

    .programme-item img{
        width: 24vw;
        height: 16vw;
        transition: transform .5s ease;
    }

    .programme-item-name{
        top: 0px;
        position: absolute;
        color: white;
        width: 24vw;
        height: 16vw;
        background-color: rgba(0,0,0,0.2);
        line-height: 16vw;
        text-align: center;
        z-index: 200;
        font-size: 1vw;
    }


    .programme-item:hover{
        box-shadow: 2px 2px 4px 1px rgba(0, 0, 0, 0.5);
        cursor: pointer;
    }

    .programme-item:hover .programme-item-name{
        background-color: rgba(0,0,0,0.5);
    }

    .programme-item:hover img{
        transform: scale(1.5);
    }

    .programme-item-name:hover {
        font-size: 1.5vw;
        /*animation: ;*/
    }


    @media (min-width: 768px){
        .container {
            width: 100%;
        }
        .top-bar-img,.top-bar-img img{
            width: 100%;
            height: 25vw;
        }


    }

    img{
        object-fit: cover;
    }

    @media (max-width: 767px) {

        .wrap > .container {
            padding: 50px 0px 0px;
        }

        .container {
            width: 100%;
        }

        .top-bar-img,.top-bar-img img{
            width: 100vw;
            height: 45vw;
        }
        h2{
            margin: auto;
        }


        .programmes{
            background: white;
            width: 100vw;
        }


        .programme-item{
            width:80vw;
            height: 35vw;
            display: inline-flex;
            text-align: center;
            margin: 1vw 10vw 1vw;
        }

        .programme-item img{
            width: 80vw;
            height: 35vw;
        }


        .programme-item-name{
            top: 0px;
            position: absolute;
            color: white;
            width: 80vw;
            height: 35vw;
            background-color: rgba(0,0,0,0.5);
            line-height:35vw;
            text-align: center;
            z-index: 200;
            font-size: 3vw;
        }

    }

    @media (min-width: 970px) {
        .programmes-content{
            width: 970px;
            margin: auto;
        }
    }

</style>
