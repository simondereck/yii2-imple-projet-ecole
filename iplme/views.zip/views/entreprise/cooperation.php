<?php
/**
 * Created by PhpStorm.
 * User: 37vip
 * Date: 24/11/2019
 * Time: 19:32
 */
?>

<div class="cooperation">
    <div class="top-bar-img">
        <img src="../../images/iplme/cooperation.jpg" />
        <div>Cooperation</div>
    </div>
    <div class="cooperation-info">
        <section class="grid-x color-primary">
            <div class="padding-top-3 cell" style="">
                <p>Les entreprises peuvent interagir avec les étudiants d'IPLME de différentes manières. Les diplômés et les professeurs d'IPLME établissent des contacts afin de  recruter des talents ou promouvoir le développement de leur propre marque.</p>
                <p> Au cours de l'année, nous avons organisé des journées professionnelles internationales, des défis pour les étudiants et des formations de troisième cycle, ainsi que des conférences et des séminaires pour des entreprises de renommée mondiale. Nous avons également une plate-forme de réseau de développement de carrière qui sert de pont entre nos partenaires d'affaires et nos étudiants.</p>
            </div>
        </section>
        <section class="grid-x xlarge-up-3 small-up-1 color-white">
            <div class="cell" style="">
                <h4 class="section-title text-">Interaction &amp; recrutement</h4>
                <ul>
                    <li>en tant que  représentant participez à la foire de recrutement </li>
                    <li>Entrez dans la salle de classe ou donnez une conférence</li>
                    <li>Lancer des jeux d'affaires et des défis</li>
                    <li>projets de conseil en recrutement</li>
                    <li>Participer à des entrevues simulées</li>
                </ul>
            </div>
            <div class="cell" style="">
                <h4 class="section-title text-">Développez votre propre marque</h4>
                <ul>
                    <li>Collaborer avec les enseignants pour mener des recherches</li>
                </ul>
            </div>
            <a class="anchor-link-item back-to-top" href="#article-top" style="">
                <div class="fa fa-angle-up">
                </div>
            </a>
        </section>
    </div>
</div>


<style>
    body{
        background-color: whitesmoke;
    }

    .cooperation{
        width: 60vw;
        margin: 20px auto 20px;
        background-color: #31567C;
        color: white;
    }

    .top-bar-img,.top-bar-img img{
        width: 60vw;
        height: 20vw;
        position: relative;
    }

    .top-bar-img div{
        font-size: 2vw;
        color: white;
        padding: 2vw;
        position: absolute;
        top: 0;
        z-index: 200;
    }

    .cooperation-info{
        padding: 2vw;
        font-size: 1vw;
    }


</style>
