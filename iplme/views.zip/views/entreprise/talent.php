<?php
/**
 * Created by PhpStorm.
 * User: 37vip
 * Date: 24/11/2019
 * Time: 19:32
 */
?>

<div class="talent">
    <div class="top-bar-img">
        <img src="../../images/iplme/talent.jpg" />
        <div>Talent</div>
    </div>
    <div class="talent-info">
        <section class="grid-x color-white">
            <div class="padding-top-3 cell" style="">
                <p> L’IPLME offre toute une gamme d'avantages et de possibilités d'évolution de carrière  en français, y compris des programmes de maîtrise multilingues et des programmes de responsabilité d'entreprise. En outre, nous offrons des programmes d'études supérieures et des cours de formation personnalisés pour les candidats et les cadres expérimentés.</p>
                <p>Consultez notre programme de gestion avancé actuel.</p>
                <p>Contactez-nous pour en savoir plus sur les options de développement de carrière.</p>
            </div>
        </section>
    </div>
</div>


<style>
    body{
        background-color: whitesmoke;
    }

    .talent{
        width: 60vw;
        margin: 20px auto 20px;
        background-color: #31567C;
        color: white;
    }

    .top-bar-img,.top-bar-img img{
        width: 60vw;
        height: 20vw;
        position: relative;
    }

    .top-bar-img div{
        font-size: 2vw;
        color: white;
        padding: 2vw;
        position: absolute;
        top: 0;
        z-index: 200;
    }


    .talent-info{
        padding: 2vw;
        font-size: 1vw;
    }


</style>
