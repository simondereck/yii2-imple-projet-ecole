<?php
/**
 * Created by PhpStorm.
 * User: 37vip
 * Date: 24/11/2019
 * Time: 19:33
 */
//soutenez?>


<div class="soutenez">
    <div class="top-bar-img">
        <img src="../../images/iplme/apercu.jpg" />
        <div>Soutenez-vous</div>
    </div>
    <div class="soutenez-info">
        <section class="grid-x color-white">
            <div class="padding-top-3 cell" style="">
                <p>Il existe plusieurs façons de soutenir l’IPLME:</p>
                <ul>
                    <li>Diversité: parrainer les représentants des étudiants qui ont moins d'opportunités d'étudier à l'étranger. Contactez notre équipe d'admissions internationales pour plus d’information.</li>
                    <li>Recherche avancée: Financer la création de l'Institut pour traiter des problèmes spécifiques de gestion.</li>
                    <li>Promouvoir les échanges internationaux: Soutenir l'Académie à travers la Fondation IPLME pour promouvoir l'innovation éducative, l'ouverture culturelle et l'internationalisation de la recherche.</li>
                </ul>
            </div>
        </section>
    </div>
</div>


<style>
    body{
        background-color: whitesmoke;
    }

    .soutenez{
        width: 60vw;
        margin: 20px auto 20px;
        background-color: #31567C;
        color: white;
    }

    .top-bar-img,.top-bar-img img{
        width: 60vw;
        height: 20vw;
        position: relative;
    }

    .top-bar-img div{
        font-size: 2vw;
        color: white;
        padding: 2vw;
        position: absolute;
        top: 0;
        z-index: 200;
    }

    .soutenez-info{
        padding: 2vw;
        font-size: 1vw;
    }


</style>
