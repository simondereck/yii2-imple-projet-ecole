<?php

/* @var $this \yii\web\View */
/* @var $content string */

use iplme\assets\AppAsset;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use common\widgets\Alert;
Yii::$app->name="IPLME";
AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="école supérieure de commerce,business school,école de management,masters,Mastères,MBA,formation continue Nantes,Audencia,Nantes,grande ecole,sai,em lyon,grenoble,国际硕士,法国,商学院,法国高商,大学校,法国硕士,法国留学,法国高等商学院,法国排名前十的高商,FT法国高商排名,供应链与采购管理,食品学与农业企业管理,艺术创新与创业管理,国际管理学硕士,咨询专业,体育管理全法排名第一,艺术管理,大学校管理学硕士,法国国家文凭,法国精英文凭">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' =>  Html::img('../../images/iplme/logo.png', ['alt'=>Yii::$app->name,'height'=>'50px']),
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
            'style'=>'background-color:#122130;height:80px;line-height:80px;font-size:1.25vw;'
        ],
    ]);
    $menuItems = [
        ['label' => 'Home', 'url' => ['/site/index']],
    ];

    $menuItems = [
        ['label'=>'Notre Ecole','url'=>"index.php?r=ecole/index"],
        ['label'=>'Entreprise','url'=>'index.php?r=entreprise/index'],
        ['label'=>'Vie Etudiant','url'=>"index.php?r=vie/index"],
        ['label'=>'Cours en Ligne','url'=>'index.php?r=cours/index'],
        ['label'=>'Formulaire Inscription','url'=>'index.php?r=inscription/index'],
        ['label' => 'MyIPLME', 'url'=>'../../admin/web/index.php?r=site/index'],
        [
            'label'=> Html::img('../../images/iplme/fr.jpg', ['alt'=>'zh','height'=>'18px']),
            'url'=>'index.php?r=site/langue'
        ]
    ];


    echo Nav::widget([
        'options' => [
                'class' => 'navbar-nav navbar-right',
        ],
        'encodeLabels' => false,
        'items' => $menuItems,

    ]);
    NavBar::end();
    ?>

    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <div>
            <nav class="second-nav">
                <ul class="second-nav-ul">
                    <li data-href="index">Notre école</li>
                    <li data-href="presentation">Présentation</li>
                    <li data-href="vision">Vision</li>
                    <li data-href="campus">Campus</li>
                    <li data-href="professeur">Professeur</li>
                    <li data-href="contact">Contactez nous</li>
                </ul>
            </nav>
        </div>
        <?= $content ?>
    </div>

</div>

<footer class="bottom-bar">
    <div class="footer-top">
        <div>
            <h3>> Coordonnées</h3>
            <div>
                <label>Addr : </label>
                <div>118 -120 Rue de l'Abbé Groult 75015 Paris</div>
                <label>Tel : </label>
                <div>+33 (0)1 45 30 02 29,+33 (0)9 82 38 90 78</div>
                <label>Email : </label>
                <div>info@iplme.org</div>
            </div>
        </div>
        <div>
            <h3>> Nous Suivre</h3>
            <div class="socail">
                <button href="https://www.facebook.com/iplm.pairs" class="fa fa-facebook-square"></button>
                <button href="https://twitter.com/IPLME_paris" class="fa fa-twitter-square"></button>
                <button href="https://www.youtube.com/channel/UCSOwCJVTPF6ikCe42cLp68A?view_as=subscriber" class="fa fa-youtube-square"></button>
                <button href="https://www.linkedin.com/feed/?trk=onboarding-landing" class="fa fa-linkedin-square"></button>
            </div>
            <div class="qr-code">
                <div class="qr-code-item">
                    <img src="../../images/iplme/wechat.jpg" />
                    <div>Wechat</div>
                    <div>IPLME</div>
                </div>
                <div class="qr-code-item">
                    <img src="../../images/iplme/weibo.jpg" />
                    <div>Weibo</div>
                    <div>IPLME</div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-line">
        <div></div>
        <div class="footer-line-center">
            <div class="footer-bottom">
                <img src="../../images/iplme/logo.png"/>
            </div>
            <div class="footer-date">
                <p>&copy;  <?= date('Y')?>&nbsp;<?= Html::encode(Yii::$app->name) ?> - Tout doit réservé</p>
            </div>
        </div>
        <div>
        </div>
    </div>


</footer>

<script>
    $('.second-nav-ul').on('click','li',function () {
        let val = $(this).attr('data-href');
        window.location = 'index.php?r=ecole/'+val;
    });
    $('.socail').on('click','button',function () {
        let url = $(this).attr('href');
        window.open(url);
    });


</script>
<style>
    body{
        font-family: -apple-system,
        system-ui,BlinkMacSystemFont,
        "Segoe UI","Hiragino Sans GB","PingFang SC","Microsoft YaHei","WenQuanYi Micro Hei",sans-serif;
        font-weight:normal;

    }

    .navbar-fixed-top li{
        height: 80px;
        line-height: 80px
        background-color:#122130;
    }

    .navbar-fixed-top li>a{
        height: 50px;
        line-height: 50px;
    }

    .navbar-fixed-top li:hover{
        border-top: 2px solid white;
        border-bottom: 2px solid white;
    }

    .bottom-bar{
        background-color: #122130;
        color: white;
        padding: 10px;

        font-weight: lighter;
    }

    .footer-top{
        display: flex;
        justify-content: space-around;
    }
    .bottom-bar h3,label{
        font-weight: lighter;
    }
    .socail button{
        background-color: transparent;
        border: none;
        font-size: 2.5vw;
    }

    .qr-code{
        display: flex;
        margin-top: 10px;
        justify-content: space-around;
    }

    .qr-code img{
        width: 96px;
        height: 96px;
        background-color: transparent;
        padding: 4px;
    }
    .qr-code-item{
        text-align: center;
    }

    .footer-line{
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
    }

    .footer-line-center{
        width: 80vw;
        border-top: 1px solid whitesmoke;
        padding: 10px;
    }


    .footer-bottom img{
        width: 300px;
        height: 50px;
        object-fit: contain;
    }

    .footer-line-center{
        display:flex ;
        line-height: 50px;
    }

    .second-nav{
        background-color: #31567C;
        color: whitesmoke;
        font-size: 1.25vw;
    }

    .second-nav-ul{
        margin: 0;
        padding: 10px;
    }

    .second-nav-ul li{
        display: inline;
        list-style: none; /* pour enlever les puces sur IE7 */
        padding: 10px;
    }

    .second-nav-ul li:hover{
        background-color: rgba(0,0,0,0.2);
        color: white;
        cursor:pointer;
    }


    .wrap > .container {
        padding: 80px 0px 0px;
    }


    @media (min-width: 768px){

        .container {
            width: 100%;
        }
        .footer-line-center{

        }
        /*.top-bar-img,.top-bar-img img{*/
            /*width: 100%;*/
            /*height: 25vw;*/
        /*}*/

    }

    @media (max-width: 767px) {
        /*.top-bar-img,.top-bar-img img{*/
            /*width: 100%;*/
            /*height: 45vw;*/
        /*}*/
        .second-nav-ul{
            display: inline-block;
        }
        .second-nav-ul li{
            display: inline-flex;
        }

        .footer-bottom img{
            width: 70vw;
            height: 50px;
            object-fit: contain;
        }

        .footer-top{
            display: block;
            justify-content: space-around;
        }

        .footer-line-center{
            display: block;
        }

        .footer-date{
            margin-top: 10px;
            text-align: center;
        }
    }
</style>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
